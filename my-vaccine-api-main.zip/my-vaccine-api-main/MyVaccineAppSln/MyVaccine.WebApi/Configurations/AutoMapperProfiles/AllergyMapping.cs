﻿using AutoMapper;
using MyVaccine.WebApi.Dtos.Allergy;
using MyVaccine.WebApi.Models;

namespace MyVaccine.WebApi.Configurations.AutoMapperProfiles
{
    public class AllergyMapping : Profile
    {
        public AllergyMapping()
        {
            CreateMap<Allergy, AllergyResponseDto>();
            CreateMap<AllergyRequestDto, Allergy>();
        }
    }
}
