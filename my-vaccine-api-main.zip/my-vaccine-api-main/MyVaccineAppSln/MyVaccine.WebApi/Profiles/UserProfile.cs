using AutoMapper;
using MyVaccine.WebApi.Dtos.User;
using MyVaccine.WebApi.Models;

namespace MyVaccine.WebApi.Profiles
{
    public class UserProfile : Profile
    {
        public UserProfile()
        {
            CreateMap<User, UserResponseDto>();
            CreateMap<UserRequestDto, User>();
        }
    }
}
