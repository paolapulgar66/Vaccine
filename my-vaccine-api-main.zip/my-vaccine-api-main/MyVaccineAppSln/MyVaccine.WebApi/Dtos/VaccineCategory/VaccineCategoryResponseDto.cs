﻿namespace MyVaccine.WebApi.Dtos.VaccineCategory
{
    public class VaccineCategoryResponseDto : VaccineCategoryRequestDto
    {
        public int VaccineCategoryId { get; set; }
    }
}
