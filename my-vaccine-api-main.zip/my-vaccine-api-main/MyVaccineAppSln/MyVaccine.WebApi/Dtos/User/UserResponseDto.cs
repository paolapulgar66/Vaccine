// Dtos/User/UserResponseDto.cs

namespace MyVaccine.WebApi.Dtos.User
{
    public class UserResponseDto
    {
        // El Id es string porque en Identity es un GUID (string)
        public string Id { get; set; } = default!;

        public string Document { get; set; } = default!;
        public string FullName { get; set; } = default!;
        public string Email { get; set; } = default!;
    }
}
