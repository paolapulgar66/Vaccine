// Dtos/User/UserRequestDto.cs
namespace MyVaccine.WebApi.Dtos.User
{
    public class UserRequestDto
    {
        // Usa las propiedades que realmente tenga tu entidad User
        public string Document { get; set; }
        public string FullName { get; set; }
        public string Email { get; set; }
    }
}
