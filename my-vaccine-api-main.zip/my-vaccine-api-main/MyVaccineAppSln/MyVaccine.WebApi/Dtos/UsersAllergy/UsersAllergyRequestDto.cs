﻿namespace MyVaccine.WebApi.Dtos.UsersAllergy
{
    public class UsersAllergyRequestDto
    {
        public string UserId { get; set; } = null!;


        public int AllergyId { get; set; }
    }
}
