﻿using MyVaccine.WebApi.Models;

namespace MyVaccine.WebApi.Dtos.UsersAllergy
{
    public class UsersAllergyResponseDto: UsersAllergyRequestDto
    {
        public int UserAllergyId { get; set; }
    }
}
