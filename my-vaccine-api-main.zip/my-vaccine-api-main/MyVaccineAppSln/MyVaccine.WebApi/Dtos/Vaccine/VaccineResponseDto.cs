﻿namespace MyVaccine.WebApi.Dtos.Vaccine
{
    public class VaccineResponseDto: VaccineRequestDto
    {
        public int VaccineId { get; set; }
    }
}
