﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using MyVaccine.WebApi.Dtos.UsersAllergy;
using MyVaccine.WebApi.Services.Contracts;

namespace MyVaccine.WebApi.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    [AllowAnonymous] 
    public class UsersAllergyController : ControllerBase
    {
        private readonly IUsersAllergyService _usersAllergyService;

        public UsersAllergyController(IUsersAllergyService usersAllergyService)
        {
            _usersAllergyService = usersAllergyService;
        }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<UsersAllergyResponseDto>>> GetByUser([FromQuery] string userId)
        {
            if (string.IsNullOrWhiteSpace(userId))
                return BadRequest("userId is required.");

            var list = await _usersAllergyService.GetByUserAsync(userId);
            return Ok(list);
        }

        
        [HttpGet("{allergyId:int}")]
        public async Task<ActionResult<UsersAllergyResponseDto>> GetByUserAndAllergy(
            int allergyId,
            [FromQuery] string userId)
        {
            if (string.IsNullOrWhiteSpace(userId))
                return BadRequest("userId is required.");

            var item = await _usersAllergyService.GetByUserAndAllergyAsync(userId, allergyId);

            if (item is null)
                return NotFound();

            return Ok(item);
        }

   
        [HttpPost]
        public async Task<ActionResult<UsersAllergyResponseDto>> Create([FromBody] UsersAllergyRequestDto dto)
        {
            if (string.IsNullOrWhiteSpace(dto.UserId))
                return BadRequest("UserId is required.");

            var created = await _usersAllergyService.CreateAsync(dto);

            return CreatedAtAction(nameof(GetByUserAndAllergy),
                new { allergyId = created.AllergyId, userId = created.UserId },
                created);
        }

        [HttpDelete("{allergyId:int}")]
        public async Task<IActionResult> Delete(
            int allergyId,
            [FromQuery] string userId)
        {
            if (string.IsNullOrWhiteSpace(userId))
                return BadRequest("userId is required.");

            var deleted = await _usersAllergyService.DeleteAsync(userId, allergyId);

            if (!deleted)
                return NotFound();

            return NoContent();
        }
    }
}
