﻿using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using AutoMapper;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using MyVaccine.WebApi.Dtos;
using MyVaccine.WebApi.Dtos.User;
using MyVaccine.WebApi.Models;
using MyVaccine.WebApi.Repositories.Contracts;
using MyVaccine.WebApi.Services.Contracts;

namespace MyVaccine.WebApi.Services.Implementations
{
    public class UserService : IUserService
    {
        private readonly UserManager<User> _userManager;
        private readonly IUserRepository _userRepository;
        private readonly IMapper _mapper;

        public UserService(
            UserManager<User> userManager,
            IUserRepository userRepository,
            IMapper mapper)
        {
            _userManager = userManager;
            _userRepository = userRepository;
            _mapper = mapper;
        }

       
        public async Task<AuthResponseDto> AddUserAsync(RegisterRequetDto request)
        {
            var response = new AuthResponseDto();

            try
            {
                var result = await _userRepository.AddUser(request);

                if (result != null)
                {
                    response.IsSuccess = result.Succeeded;
                    response.Errors = result.Errors?
                        .Select(x => x.Description)
                        .ToArray() ?? Array.Empty<string>();
                }
                else
                {
                    response.IsSuccess = false;
                    response.Errors = new[] { "No se pudo registrar el usuario." };
                }
            }
            catch (Exception ex)
            {
                response.IsSuccess = false;
                response.Errors = new[] { ex.Message };
            }

            return response;
        }

        public async Task<AuthResponseDto> Login(LoginRequestDto request)
        {
            var response = new AuthResponseDto();

            try
            {
                var user = await _userManager.FindByNameAsync(request.Username);

                if (user != null && await _userManager.CheckPasswordAsync(user, request.Password))
                {
                    var claims = new[]
                    {
                        new Claim(ClaimTypes.Name, user.UserName!)
                    };

                    var key = new SymmetricSecurityKey(
                        Encoding.UTF8.GetBytes("A2*7gF9@D#1hJ$5mNpRtVwYzZ&k8zbx"));

                    var creds = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);

                    var token = new JwtSecurityToken(
                        claims: claims,
                        expires: DateTime.UtcNow.AddMonths(15),
                        signingCredentials: creds
                    );

                    response.Token = new JwtSecurityTokenHandler().WriteToken(token);
                    response.Expiration = token.ValidTo;
                    response.IsSuccess = true;
                }
                else
                {
                    response.IsSuccess = false;
                    response.Errors = new[] { "Credenciales incorrectas." };
                }
            }
            catch (Exception ex)
            {
                response.IsSuccess = false;
                response.Errors = new[] { ex.Message };
            }

            return response;
        }

        public async Task<AuthResponseDto> RefreshToken(string email)
        {
            var response = new AuthResponseDto();

            try
            {
                var user = await _userManager.FindByNameAsync(email);

                if (user != null)
                {
                    var claims = new[]
                    {
                        new Claim(ClaimTypes.Name, user.UserName!)
                    };

                    var key = new SymmetricSecurityKey(
                        Encoding.UTF8.GetBytes("A2*7gF9@D#1hJ$5mNpRtVwYzZ&k8zbx"));

                    var creds = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);

                    var token = new JwtSecurityToken(
                        claims: claims,
                        expires: DateTime.UtcNow.AddMonths(15),
                        signingCredentials: creds
                    );

                    response.Token = new JwtSecurityTokenHandler().WriteToken(token);
                    response.Expiration = token.ValidTo;
                    response.IsSuccess = true;
                }
                else
                {
                    response.IsSuccess = false;
                    response.Errors = new[] { "Usuario no encontrado." };
                }
            }
            catch (Exception ex)
            {
                response.IsSuccess = false;
                response.Errors = new[] { ex.Message };
            }

            return response;
        }

        public async Task<UserDto?> GetUserInfo(string email)
        {
            var user = await _userManager.FindByNameAsync(email);
            if (user == null) return null;

            var userFull = await _userRepository
                .FindByAsNoTracking(x => x.Id == user.Id)
                .Include(x => x.FamilyGroups)
                .FirstOrDefaultAsync();

            if (userFull == null) return null;

            return _mapper.Map<UserDto>(userFull);
        }

    

     
        public Task<UserResponseDto?> GetByIdAsync(int id)
        {
            throw new NotImplementedException("No usar este método. Usa GetByIdAsync(string id).");
        }

        public Task<bool> UpdateAsync(int id, UserRequestDto dto)
        {
            throw new NotImplementedException("No usar este método. Usa UpdateAsync(string id, UserRequestDto).");
        }

        public Task<bool> DeleteAsync(int id)
        {
            throw new NotImplementedException("No usar este método. Usa DeleteAsync(string id).");
        }

        public async Task<IEnumerable<UserResponseDto>> GetAllAsync()
        {
            var list = await _userRepository
                .FindByAsNoTracking(x => true)
                .ToListAsync();

            return _mapper.Map<IEnumerable<UserResponseDto>>(list);
        }

        public async Task<UserResponseDto?> GetByIdAsync(string id)
        {
            var user = await _userRepository
                .FindByAsNoTracking(x => x.Id == id)
                .FirstOrDefaultAsync();

            if (user == null) return null;

            return _mapper.Map<UserResponseDto>(user);
        }

        public async Task<UserResponseDto> CreateAsync(UserRequestDto dto)
        {
            var entity = _mapper.Map<User>(dto);

            await _userRepository.Add(entity);

            return _mapper.Map<UserResponseDto>(entity);
        }

        public async Task<bool> UpdateAsync(string id, UserRequestDto dto)
        {
            var entity = await _userRepository
                .FindBy(x => x.Id == id)
                .FirstOrDefaultAsync();

            if (entity == null) return false;

            _mapper.Map(dto, entity);
            await _userRepository.Update(entity);

            return true;
        }

        public async Task<bool> DeleteAsync(string id)
        {
            var entity = await _userRepository
                .FindBy(x => x.Id == id)
                .FirstOrDefaultAsync();

            if (entity == null) return false;

            await _userRepository.Delete(entity);

            return true;
        }
    }
}
