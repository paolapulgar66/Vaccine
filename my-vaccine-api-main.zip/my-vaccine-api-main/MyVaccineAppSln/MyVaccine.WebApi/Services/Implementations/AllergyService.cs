﻿using AutoMapper;
using Microsoft.EntityFrameworkCore;
using MyVaccine.WebApi.Dtos.Allergy;
using MyVaccine.WebApi.Models;
using MyVaccine.WebApi.Repositories.Contracts;
using MyVaccine.WebApi.Services.Contracts;

namespace MyVaccine.WebApi.Services.Implementations
{
    public class AllergyService : IAllergyService
    {
        private readonly IBaseRepository<Allergy> _allergyRepository;
        private readonly IMapper _mapper;

        public AllergyService(IBaseRepository<Allergy> allergyRepository, IMapper mapper)
        {
            _allergyRepository = allergyRepository;
            _mapper = mapper;
        }

        // ============================
        // GET ALL
        // ============================
        public async Task<IEnumerable<AllergyResponseDto>> GetAllAsync()
        {
            var list = await _allergyRepository
                .FindByAsNoTracking(x => true)
                .ToListAsync();

            return _mapper.Map<IEnumerable<AllergyResponseDto>>(list);
        }

        // ============================
        // GET BY ID
        // ============================
        public async Task<AllergyResponseDto?> GetByIdAsync(int id)
        {
            var entity = await _allergyRepository
                .FindByAsNoTracking(x => x.AllergyId == id)
                .FirstOrDefaultAsync();

            if (entity == null)
                return null;

            return _mapper.Map<AllergyResponseDto>(entity);
        }

        // ============================
        // CREATE
        // ============================
        public async Task<AllergyResponseDto> CreateAsync(AllergyRequestDto dto)
        {
            var entity = _mapper.Map<Allergy>(dto);

            await _allergyRepository.Add(entity);   // NO Save()

            return _mapper.Map<AllergyResponseDto>(entity);
        }

        // ============================
        // UPDATE
        // ============================
        public async Task<bool> UpdateAsync(int id, AllergyRequestDto dto)
        {
            var entity = await _allergyRepository
                .FindBy(x => x.AllergyId == id)
                .FirstOrDefaultAsync();

            if (entity == null)
                return false;

            _mapper.Map(dto, entity);

            // Usamos Update del repositorio (igual que otros servicios)
            await _allergyRepository.Update(entity);   // NO Save()

            return true;
        }

        // ============================
        // DELETE
        // ============================
        public async Task<bool> DeleteAsync(int id)
        {
            var entity = await _allergyRepository
                .FindBy(x => x.AllergyId == id)
                .FirstOrDefaultAsync();

            if (entity == null)
                return false;

            await _allergyRepository.Delete(entity);   // NO Save()

            return true;
        }
    }
}
