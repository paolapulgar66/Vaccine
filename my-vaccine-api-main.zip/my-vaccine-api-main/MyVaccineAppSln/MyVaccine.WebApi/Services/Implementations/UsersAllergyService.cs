﻿using AutoMapper;
using Microsoft.EntityFrameworkCore;
using MyVaccine.WebApi.Dtos.UsersAllergy;
using MyVaccine.WebApi.Models;
using MyVaccine.WebApi.Repositories.Contracts;
using MyVaccine.WebApi.Services.Contracts;

namespace MyVaccine.WebApi.Services.Implementations
{
    public class UsersAllergyService : IUsersAllergyService
    {
        private readonly IBaseRepository<UsersAllergy> _usersAllergyRepository;
        private readonly IMapper _mapper;

        public UsersAllergyService(
            IBaseRepository<UsersAllergy> usersAllergyRepository,
            IMapper mapper)
        {
            _usersAllergyRepository = usersAllergyRepository;
            _mapper = mapper;
        }

        public async Task<IEnumerable<UsersAllergyResponseDto>> GetByUserAsync(string userId)
        {
            var list = await _usersAllergyRepository
                .FindByAsNoTracking(x => x.UserId == userId)
                .Include(x => x.Allergy)
                .ToListAsync();

            return _mapper.Map<IEnumerable<UsersAllergyResponseDto>>(list);
        }

        public async Task<UsersAllergyResponseDto?> GetByUserAndAllergyAsync(string userId, int allergyId)
        {
            var entity = await _usersAllergyRepository
                .FindByAsNoTracking(x => x.UserId == userId && x.AllergyId == allergyId)
                .Include(x => x.Allergy)
                .FirstOrDefaultAsync();

            return entity == null
                ? null
                : _mapper.Map<UsersAllergyResponseDto>(entity);
        }

        public async Task<UsersAllergyResponseDto> CreateAsync(UsersAllergyRequestDto dto)
        {
            var entity = _mapper.Map<UsersAllergy>(dto);

            await _usersAllergyRepository.Add(entity);

            return _mapper.Map<UsersAllergyResponseDto>(entity);
        }

        public async Task<bool> DeleteAsync(string userId, int allergyId)
        {
            var entity = await _usersAllergyRepository
                .FindBy(x => x.UserId == userId && x.AllergyId == allergyId)
                .FirstOrDefaultAsync();

            if (entity == null)
                return false;

            await _usersAllergyRepository.Delete(entity);

            return true;
        }
    }
}
