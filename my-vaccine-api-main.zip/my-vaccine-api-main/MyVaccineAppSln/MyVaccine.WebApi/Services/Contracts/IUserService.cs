﻿using MyVaccine.WebApi.Dtos;
using MyVaccine.WebApi.Dtos.User;

namespace MyVaccine.WebApi.Services.Contracts
{
    public interface IUserService
    {
       
        Task<AuthResponseDto> AddUserAsync(RegisterRequetDto request);
        Task<AuthResponseDto> Login(LoginRequestDto request);
        Task<AuthResponseDto> RefreshToken(string email);
        Task<UserDto?> GetUserInfo(string email);    
        Task<IEnumerable<UserResponseDto>> GetAllAsync();
        Task<UserResponseDto?> GetByIdAsync(string id);
        Task<UserResponseDto> CreateAsync(UserRequestDto dto);
        Task<bool> UpdateAsync(string id, UserRequestDto dto);
        Task<bool> DeleteAsync(string id);
    }
}
