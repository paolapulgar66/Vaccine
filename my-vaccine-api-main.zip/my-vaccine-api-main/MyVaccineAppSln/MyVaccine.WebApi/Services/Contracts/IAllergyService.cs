﻿using MyVaccine.WebApi.Dtos.Allergy;

namespace MyVaccine.WebApi.Services.Contracts
{
    public interface IAllergyService
    {
        Task<IEnumerable<AllergyResponseDto>> GetAllAsync();
        Task<AllergyResponseDto?> GetByIdAsync(int id);
        Task<AllergyResponseDto> CreateAsync(AllergyRequestDto dto);
        Task<bool> UpdateAsync(int id, AllergyRequestDto dto);
        Task<bool> DeleteAsync(int id);
    }
}
