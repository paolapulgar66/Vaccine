﻿using MyVaccine.WebApi.Dtos.UsersAllergy;

namespace MyVaccine.WebApi.Services.Contracts
{
    public interface IUsersAllergyService
    {
        Task<IEnumerable<UsersAllergyResponseDto>> GetByUserAsync(string userId);
        Task<UsersAllergyResponseDto?> GetByUserAndAllergyAsync(string userId, int allergyId);
        Task<UsersAllergyResponseDto> CreateAsync(UsersAllergyRequestDto dto);
        Task<bool> DeleteAsync(string userId, int allergyId);
    }
}
