﻿namespace MyVaccine.WebApi.Models
{
    public class Allergy
    {
        public int AllergyId { get; set; }
        public string Name { get; set; }
        public ICollection<UsersAllergy> UsersAllergies { get; set; }
    }
}
