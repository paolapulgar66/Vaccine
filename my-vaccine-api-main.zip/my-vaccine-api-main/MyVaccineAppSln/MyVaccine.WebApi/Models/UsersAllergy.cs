﻿namespace MyVaccine.WebApi.Models
{
    public class UsersAllergy
    {
        public int UserAllergyId { get; set; }

        public string UserId { get; set; } = null!;
        public User User { get; set; } = null!;

        public int AllergyId { get; set; }
        public Allergy Allergy { get; set; } = null!;
    }
}
